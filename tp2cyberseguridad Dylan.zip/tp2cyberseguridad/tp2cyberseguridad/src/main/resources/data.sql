INSERT INTO users (username, email, role, password, secret_api_key) VALUES
('eri_dev', 'eri@empresa.com', 'ADMIN', '$2a$10$hashedPasswordExample1', 'sk_live_51Hj9F3xAdminKey');

INSERT INTO users (username, email, role, password, secret_api_key) VALUES
('jorge_user', 'jorge@empresa.com', 'USER', '$2a$10$hashedPasswordExample2', 'sk_live_51Hj9F3xUserKey');