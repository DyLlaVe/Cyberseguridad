package com.example.tp.dylan.tp2cyberseguridad.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.example.tp.dylan.tp2cyberseguridad.dto.UserDTO;
import com.example.tp.dylan.tp2cyberseguridad.model.User;
import com.example.tp.dylan.tp2cyberseguridad.service.UserService;

@RestController
public class UserController {

    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/api/vulnerable/users/{id}")
    public User getUserVulnerable(@PathVariable Long id) {
        return userService.getUserVulnerable(id);
    }

    @GetMapping("/api/mitigated/users/{id}")
    public UserDTO getUserMitigated(@PathVariable Long id) {
        return userService.getUserMitigated(id);
    }
}
