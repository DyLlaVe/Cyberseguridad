package com.example.tp.dylan.tp2cyberseguridad.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.tp.dylan.tp2cyberseguridad.model.User;

public interface UserRepository extends JpaRepository<User, Long> {
}