package com.example.tp.dylan.tp2cyberseguridad.service;

import org.springframework.stereotype.Service;

import com.example.tp.dylan.tp2cyberseguridad.dto.UserDTO;
import com.example.tp.dylan.tp2cyberseguridad.exception.UserNotFoundException;
import com.example.tp.dylan.tp2cyberseguridad.model.User;
import com.example.tp.dylan.tp2cyberseguridad.repository.UserRepository;

@Service
public class UserService {

    private final UserRepository userRepository;

    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public User getUserVulnerable(Long id) {
        return userRepository.findById(id)
                .orElseThrow(() -> new RuntimeException(
                        "No se encontró el usuario con id " + id + " en la tabla users"));
       
    }

    public UserDTO getUserMitigated(Long id) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new UserNotFoundException(id));
        return UserDTO.fromEntity(user);
    }
}
