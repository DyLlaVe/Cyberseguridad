package com.example.tp.dylan.tp2cyberseguridad;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Tp2cyberseguridadApplication {

	public static void main(String[] args) {
		SpringApplication.run(Tp2cyberseguridadApplication.class, args);
	}

}
