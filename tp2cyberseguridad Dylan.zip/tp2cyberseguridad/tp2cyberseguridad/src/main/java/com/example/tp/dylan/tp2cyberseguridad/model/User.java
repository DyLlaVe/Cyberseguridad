package com.example.tp.dylan.tp2cyberseguridad.model;

import jakarta.persistence.*;

@Entity
@Table(name = "users")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String username;
    private String email;
    private String role;

    private String password;
    private String secretApiKey;

    public User() {}

    public User(String username, String email, String role, String password, String secretApiKey) {
        this.username = username;
        this.email = email;
        this.role = role;
        this.password = password;
        this.secretApiKey = secretApiKey;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }
    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
    public String getSecretApiKey() { return secretApiKey; }
    public void setSecretApiKey(String secretApiKey) { this.secretApiKey = secretApiKey; }
}