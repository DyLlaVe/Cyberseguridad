package com.example.tp.dylan.tp2cyberseguridad;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Tp2cyberseguridadApplicationTests {

	@Test
	void contextLoads() {
	}

}
