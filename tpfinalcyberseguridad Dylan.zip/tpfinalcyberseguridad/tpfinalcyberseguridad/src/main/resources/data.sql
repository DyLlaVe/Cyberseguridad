INSERT INTO invoice (client_name, amount, owner_username) VALUES ('Empresa Alfa (Coca-Cola Argentina)', 150000.0, 'eri_dev');
INSERT INTO invoice (client_name, amount, owner_username) VALUES ('Empresa Beta (Pepsi Co)', 85000.0, 'jorge_user');
INSERT INTO app_user (username, email, password, role, secret_api_key) VALUES ('eri_dev', 'eri@example.com', '$2a$10$educational-hash-only', 'ADMIN', 'sk-demo-eri-123');
INSERT INTO app_user (username, email, password, role, secret_api_key) VALUES ('jorge_user', 'jorge@example.com', '$2a$10$educational-hash-only', 'USER', 'sk-demo-jorge-456');
