package com.example.demo.controller;

import com.example.demo.model.User;
import com.example.demo.exception.UserNotFoundException;
import com.example.demo.repository.UserRepository;
import com.example.demo.dto.UserDTO;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/users")
public class UserController {

    private final UserRepository userRepository;

    public UserController(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    /**
     * VULNERABLE (OWASP A05: Security Misconfiguration).
     * Dos fallas de configuración combinadas:
     *  1) Serializa la entidad completa, exponiendo campos sensibles (password, secretApiKey)
     *     porque nunca se restringió la salida a un DTO.
     *  2) Al lanzar una excepción no controlada, Spring devuelve el stack trace completo
     *     porque "server.error.include-stacktrace=always" quedó habilitado
     *     (ver application.properties), revelando detalles internos de la aplicación.
     */
    @GetMapping("/vulnerable/{id}")
    public User getVulnerableUser(@PathVariable Long id) {
        return userRepository.findById(id)
                .orElseThrow(() -> new RuntimeException(
                        "Error interno al buscar el usuario con ID: " + id));
    }

    /**
     * MITIGADO: aunque el flag global "server.error.include-stacktrace=always" sigue
     * activo a nivel de aplicación, este endpoint no queda expuesto a esa mala
     * configuración porque controla su propia excepción (UserNotFoundException,
     * manejada por GlobalExceptionHandler) y nunca deja que el error llegue "crudo"
     * al cliente. Además, devuelve una representación pública (UserDTO) en vez de
     * la entidad completa.
     */
    @GetMapping("/mitigated/{id}")
    public ResponseEntity<UserDTO> getMitigatedUser(@PathVariable Long id) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new UserNotFoundException(
                        "El usuario con ID " + id + " no fue encontrado."));

        return ResponseEntity.ok(UserDTO.fromEntity(user));
    }
}