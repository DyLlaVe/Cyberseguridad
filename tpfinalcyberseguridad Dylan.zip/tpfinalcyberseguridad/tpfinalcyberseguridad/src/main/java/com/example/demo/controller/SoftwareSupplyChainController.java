package com.example.demo.controller;

import com.example.demo.model.SoftwareComponent;
import com.example.demo.service.SoftwareSupplyChainService;
import com.example.demo.dto.ComponentRequest;
import com.example.demo.dto.ValidationResponse;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/components")
public class SoftwareSupplyChainController {

    private final SoftwareSupplyChainService service;

    public SoftwareSupplyChainController(SoftwareSupplyChainService service) {
        this.service = service;
    }

    /**
     * ENDPOINT VULNERABLE: Demuestra OWASP A03:2025.
     * Este punto acepta cualquier componente sin validar ni el proveedor,
     * ni el origen, ni el hash SHA-256. En una implementación real, esto permitiría
     * introducir dependencias maliciosas o modificadas desde repositorios no confiables.
     */
    @PostMapping("/vulnerable")
    public ResponseEntity<ValidationResponse> registerVulnerable(@RequestBody ComponentRequest request) {
        ValidationResponse response = service.processVulnerableIngestion(request);
        return ResponseEntity.ok(response);
    }

    /**
     * ENDPOINT MITIGADO: Demuestra la solución a OWASP A03:2025.
     * Valida lista blanca de proveedores, dominio de origen permitido y coincidencia
     * estricta del SHA-256 antes de aceptar el componente. Si alguna validación falla,
     * el sistema rechaza la operación con HTTP 400.
     */
    @PostMapping("/mitigated")
    public ResponseEntity<ValidationResponse> registerMitigated(@RequestBody ComponentRequest request) {
        ValidationResponse response = service.processMitigatedIngestion(request);
        if (!response.isSuccess()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
        }
        return ResponseEntity.ok(response);
    }

    /**
     * LISTAR COMPONENTES REGISTRADOS EN MYSQL.
     * Sirve para inspeccionar qué paquetes fueron aceptados o rechazados en la base de datos.
     */
    @GetMapping
    public ResponseEntity<List<SoftwareComponent>> getAllComponents() {
        return ResponseEntity.ok(service.getAllComponents());
    }

    /**
     * LIMPIAR BASE DE DATOS.
     * Permite resetear la tabla de componentes durante la demostración.
     */
    @DeleteMapping
    public ResponseEntity<String> clearDatabase() {
        service.clearAll();
        return ResponseEntity.ok("Base de datos limpiada correctamente.");
    }
}
