package com.example.demo.model;

import jakarta.persistence.*;

@Entity
@Table(name = "software_component")
public class SoftwareComponent {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false)
    private String version;

    @Column(nullable = false)
    private String supplier;

    @Column(nullable = false)
    private String sourceUrl;

    @Column(nullable = false)
    private String sha256;

    @Column(nullable = false)
    private String expectedSha256;

    @Column(nullable = false)
    private String status;

    public SoftwareComponent() {
    }

    public SoftwareComponent(String name, String version, String supplier, String sourceUrl, String sha256, String expectedSha256, String status) {
        this.name = name;
        this.version = version;
        this.supplier = supplier;
        this.sourceUrl = sourceUrl;
        this.sha256 = sha256;
        this.expectedSha256 = expectedSha256;
        this.status = status;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getSupplier() {
        return supplier;
    }

    public void setSupplier(String supplier) {
        this.supplier = supplier;
    }

    public String getSourceUrl() {
        return sourceUrl;
    }

    public void setSourceUrl(String sourceUrl) {
        this.sourceUrl = sourceUrl;
    }

    public String getSha256() {
        return sha256;
    }

    public void setSha256(String sha256) {
        this.sha256 = sha256;
    }

    public String getExpectedSha256() {
        return expectedSha256;
    }

    public void setExpectedSha256(String expectedSha256) {
        this.expectedSha256 = expectedSha256;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
