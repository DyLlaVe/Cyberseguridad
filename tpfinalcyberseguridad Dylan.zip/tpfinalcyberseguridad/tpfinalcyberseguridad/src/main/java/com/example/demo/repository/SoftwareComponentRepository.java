package com.example.demo.repository;

import com.example.demo.model.SoftwareComponent;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface SoftwareComponentRepository extends JpaRepository<SoftwareComponent, Long> {
}
