package com.example.demo;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
class SoftwareSupplyChainControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Test
    void vulnerableEndpointAcceptsUntrustedComponent() throws Exception {
        mockMvc.perform(post("/api/components/vulnerable")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {
                                  "name": "openssl",
                                  "version": "3.2.0",
                                  "supplier": "evil-registry",
                                  "sourceUrl": "https://evil.example.net/download/openssl.tgz",
                                  "sha256": "abc123",
                                  "expectedSha256": "def456"
                                }
                                """))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.message").value(org.hamcrest.Matchers.containsString("sin validar")));
    }

    @Test
    void mitigatedEndpointRejectsUntrustedSupplierOrOrigin() throws Exception {
        mockMvc.perform(post("/api/components/mitigated")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {
                                  "name": "openssl",
                                  "version": "3.2.0",
                                  "supplier": "evil-registry",
                                  "sourceUrl": "https://evil.example.net/download/openssl.tgz",
                                  "sha256": "abc123",
                                  "expectedSha256": "abc123"
                                }
                                """))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.success").value(false))
                .andExpect(jsonPath("$.message").value(org.hamcrest.Matchers.containsString("proveedor")));
    }

    @Test
    void mitigatedEndpointAcceptsTrustedComponent() throws Exception {
        mockMvc.perform(post("/api/components/mitigated")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {
                                  "name": "openssl",
                                  "version": "3.2.0",
                                  "supplier": "acme",
                                  "sourceUrl": "https://repo.example.com/artifacts/openssl-3.2.0.tgz",
                                  "sha256": "a1b2c3d4e5f6",
                                  "expectedSha256": "a1b2c3d4e5f6"
                                }
                                """))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.message").value(org.hamcrest.Matchers.containsString("validado")));
    }
}
