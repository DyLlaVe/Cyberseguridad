Este proyecto educativo fue desarrollado en Spring Boot 3 y Java 17 para ilustrar tres ejemplos prácticos de vulnerabilidades de seguridad ampliamente conocidas en OWASP:

OWASP A01: Broken Access Control (IDOR)
OWASP A05: Security Misconfiguration
OWASP A03:2025 - Software Supply Chain Failures


## 1. OWASP A01: Broken Access Control (IDOR)

### Objetivo

Demostrar una falla de control de acceso donde un usuario puede acceder a un recurso ajeno simplemente modificando el identificador del objeto solicitado.

### Caso de uso

En la base de datos se cargan dos facturas desde [src/main/resources/data.sql](src/main/resources/data.sql):

Factura #1: pertenece a `eri_dev`
Factura #2: pertenece a `jorge_user`

Endpoint vulnerable
`/api/invoices/vulnerable/{id}`

Este endpoint devuelve la factura solicitada sin verificar si el usuario autenticado es el propietario del recurso.

Endpoint mitigado
`/api/invoices/secure/{id}`

Este endpoint valida que el `ownerUsername` de la factura coincida con el usuario que realiza la petición. Si no coincide, responde con **HTTP 403 Forbidden**.


## 2. OWASP A05: Security Misconfiguration

### Objetivo

Demostrar cómo dos fallas de configuración combinadas y no restringir la serialización de la entidad `User` terminan filtrando información interna y credenciales.

Endpoint vulnerable
`/api/users/vulnerable/{id}`

Este endpoint devuelve la entidad completa del usuario (incluyendo `password` y `secretApiKey`) y, si el usuario no existe, deja que la excepción no controlada llegue al cliente. Como la aplicación tiene `server.error.include-stacktrace=always`, esa respuesta de error incluye el stack trace completo.

Endpoint mitigado
`/api/users/mitigated/{id}`

Este endpoint muestra que la mala configuración global no es una condena si el código está bien hecho: controla su propia excepción (`UserNotFoundException` + `GlobalExceptionHandler`), por lo que nunca expone el stack trace, y devuelve un DTO público sin credenciales ni secretos.

## 3. OWASP A03:2025 - Software Supply Chain Failures

### Objetivo

Mostrar una falla en la cadena de suministro de software en la que un artefacto se acepta sin verificar:

- el proveedor,
- el origen del artefacto,
- la integridad del archivo mediante SHA-256.

Endpoint vulnerable
`/api/components/vulnerable`

Este endpoint acepta un componente sin validar el proveedor ni la integridad del archivo.

Endpoint mitigado
`/api/components/mitigated`

Este endpoint valida:

- lista blanca de proveedores,
- dominio autorizado,
- coincidencia estricta del SHA-256.

Si cualquiera de estas comprobaciones falla, la petición se rechaza con HTTP 400 Bad Request

## Ejecución

### 1. Configurar la base de datos

Ejemplo de configuración:

```properties
spring.datasource.url=jdbc:mysql://localhost:3306/invoicedb?createDatabaseIfNotExist=true&useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC
spring.datasource.username=root
spring.datasource.password=1234
```

### 2. Iniciar la aplicación

mvn spring-boot:run

O compilar y ejecutar el JAR:

mvn clean package
java -jar target/demo-0.0.1-SNAPSHOT.jar

## Colección de pruebas HTTP

Se incluye [postman-colletion.json], una colección formato Postman v2.1 con 11 peticiones documentadas, organizadas en 3 carpetas independientes —una por incidente— con la petición de ataque exitoso contra el endpoint vulnerable y su contraparte de rechazo/neutralización contra el endpoint mitigado.

## Cuadro comparativo de incidentes

**A01 - Broken Access Control (IDOR)** 

`/api/invoices/vulnerable/{id}` devuelve la factura solicitada sin comparar el usuario que la pide con el `ownerUsername` almacenado en la base de datos. 

`/api/invoices/secure/{id}` valida que el `ownerUsername` coincida con el header `X-User-Name` antes de responder; si no coincide, devuelve `403 Forbidden`. 

**A05 - Security Misconfiguration** 

`server.error.include-stacktrace=always` queda activo a nivel de aplicación y `/api/users/vulnerable/{id}` serializa la entidad `User` completa, exponiendo `password`, `secretApiKey` y, ante un error no controlado, el stack trace interno. 

`/api/users/mitigated/{id}` captura su propia excepción (`UserNotFoundException` → `GlobalExceptionHandler` → `ProblemDetail`) y responde con un DTO (`UserDTO`) que excluye los campos sensibles, evitando la fuga aunque la configuración global siga sin endurecer. 

**A03 - Software Supply Chain Failures** 

`/api/components/vulnerable` acepta cualquier componente sin validar proveedor, dominio de origen ni el hash SHA-256 declarado. 

`/api/components/mitigated` verifica lista blanca de proveedores, dominio autorizado y coincidencia estricta del SHA-256; si alguna falla, responde `400 Bad Request`. 


