package com.ejemplo.sqlinjection;

import com.ejemplo.sqlinjection.model.Usuario;
import com.ejemplo.sqlinjection.repository.UsuarioRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

/**
 * Clase principal de inicio de la aplicación Spring Boot.
 * Contiene la inicialización de datos de prueba para experimentar con SQL Injection.
 */
@SpringBootApplication
public class SqlInjectionApplication {

    public static void main(String[] args) {
        SpringApplication.run(SqlInjectionApplication.class, args);
    }

    /**
     * Bean para precargar usuarios de prueba en la base de datos MySQL al iniciar la app.
     */
    @Bean
    public CommandLineRunner initData(UsuarioRepository usuarioRepository) {
        return args -> {
            if (usuarioRepository.count() == 0) {
                usuarioRepository.save(new Usuario(null, "admin", "admin123", "administrador@empresa.com", "ADMIN", 5000.00));
                usuarioRepository.save(new Usuario(null, "juan_perez", "claveJuan2024", "juan.perez@empresa.com", "USER", 1800.50));
                usuarioRepository.save(new Usuario(null, "maria_gomez", "mariaSecret!", "maria.gomez@empresa.com", "USER", 2200.00));
                usuarioRepository.save(new Usuario(null, "carlos_ruiz", "carlosPass99", "carlos.ruiz@empresa.com", "MANAGER", 3500.75));
                System.out.println(">>> [INFO] Datos de prueba de Usuarios insertados correctamente en MySQL.");
            }
        };
    }
}
