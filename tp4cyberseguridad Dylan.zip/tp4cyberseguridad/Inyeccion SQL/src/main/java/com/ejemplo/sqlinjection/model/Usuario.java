package com.ejemplo.sqlinjection.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Entidad de persistencia que representa la tabla 'usuarios' en la base de datos MySQL.
 * Utiliza anotaciones de JPA / Hibernate y Lombok para reducir código repetitivo.
 */
@Entity
@Table(name = "usuarios")
@Data // Lombok: Genera getters, setters, toString, equals y hashCode
@NoArgsConstructor // Lombok: Genera constructor sin argumentos (requerido por JPA)
@AllArgsConstructor // Lombok: Genera constructor con todos los argumentos
public class Usuario {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Nombre de usuario único
    @Column(nullable = false, unique = true, length = 50)
    private String username;

    // Contraseña (en texto claro con fines puramente pedagógicos del laboratorio)
    @Column(nullable = false, length = 100)
    private String password;

    // Correo electrónico
    @Column(nullable = false, length = 100)
    private String email;

    // Rol de usuario en el sistema (ADMIN, USER, MANAGER)
    @Column(nullable = false, length = 20)
    private String rol;

    // Saldo o información sensible para demostrar filtración de datos no autorizados
    @Column(nullable = false)
    private Double saldo;
}
