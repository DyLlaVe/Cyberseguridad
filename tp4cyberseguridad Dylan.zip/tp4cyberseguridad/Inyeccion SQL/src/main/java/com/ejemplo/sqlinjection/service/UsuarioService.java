package com.ejemplo.sqlinjection.service;

import com.ejemplo.sqlinjection.dto.SqlResultResponse;
import com.ejemplo.sqlinjection.model.Usuario;
import com.ejemplo.sqlinjection.repository.UsuarioRepository;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

/**
 * Capa de Servicio encargada de la lógica de negocio y ejecución de consultas.
 * Contiene métodos comparativos:
 * 1. Vulnerables: Demuestran cómo la concatenación dinámica de cadenas altera la sintaxis SQL (OWASP A05:2025).
 * 2. Mitigados: Demuestran cómo el uso de consultas parametrizadas / PreparedStatements protege la integridad.
 */
@Service
public class UsuarioService {

    @PersistenceContext
    private EntityManager entityManager;

    @Autowired
    private UsuarioRepository usuarioRepository;

    // =========================================================================
    // 1. ESCENARIO LOGIN / AUTENTICACIÓN
    // =========================================================================

    /**
     * [VULNERABLE] Autenticación mediante concatenación directa de parámetros en SQL Nativo.
     * 
     * RIESGO (OWASP A05:2025 - Inyección SQL):
     * Al concatenar directamente las variables en el String, un atacante puede inyectar
     * caracteres de escape (como comillas simples ') e instrucciones SQL (' OR '1'='1)
     * para cambiar la lógica booleana de la condición WHERE y saltarse la validación de contraseña.
     */
    @SuppressWarnings("unchecked")
    public SqlResultResponse loginVulnerable(String username, String password) {
        // CONSTRUCCIÓN INSEGURA: Se concatena directamente la entrada del usuario
        String sql = "SELECT * FROM usuarios WHERE username = '" + username + "' AND password = '" + password + "'";

        List<Usuario> resultados;
        try {
            // Se ejecuta la consulta nativa en MySQL construida de forma dinámica
            resultados = entityManager.createNativeQuery(sql, Usuario.class).getResultList();
        } catch (Exception e) {
            return SqlResultResponse.builder()
                    .vulnerable(true)
                    .tipoEndpoint("VULNERABLE (Concatenación directa de SQL)")
                    .inputRecibido("username=" + username + ", password=" + password)
                    .sqlEjecutado(sql)
                    .explicacion("Error al ejecutar consulta inyectada: " + e.getMessage())
                    .totalResultados(0)
                    .datos(Collections.emptyList())
                    .build();
        }

        String explicacion = resultados.isEmpty()
                ? "Credenciales incorrectas. No se encontraron usuarios."
                : "¡ALERTA DE SEGURIDAD! Si usaste un payload como \"admin' -- \" o \"' OR '1'='1\", "
                + "la consulta se manipuló alterando la lógica SQL y saltándose la contraseña. "
                + "Se devolvieron " + resultados.size() + " registro(s).";

        return SqlResultResponse.builder()
                .vulnerable(true)
                .tipoEndpoint("VULNERABLE (Concatenación directa de SQL)")
                .inputRecibido("username=" + username + ", password=" + password)
                .sqlEjecutado(sql)
                .explicacion(explicacion)
                .totalResultados(resultados.size())
                .datos(resultados)
                .build();
    }

    /**
     * [MITIGADO / SEGURO] Autenticación mediante Consultas Parametrizadas con Spring Data JPA.
     * 
     * MITIGACIÓN (OWASP Best Practice):
     * Spring Data JPA y Hibernate usan PreparedStatements bajo el capó.
     * La base de datos compila la estructura de la consulta primero y trata
     * cualquier entrada del usuario estrictamente como DATOS literales,
     * neutralizando cualquier intento de inyección de comandos SQL.
     */
    public SqlResultResponse loginMitigado(String username, String password) {
        // Llamada al repositorio seguro con PreparedStatements
        Optional<Usuario> usuarioOpt = usuarioRepository.findByUsernameAndPassword(username, password);

        List<Usuario> resultados = usuarioOpt.map(List::of).orElse(Collections.emptyList());

        String sqlInterno = "SELECT u FROM Usuario u WHERE u.username = :username AND u.password = :password (Prepared Statement con Parameter Binding)";

        String explicacion = resultados.isEmpty()
                ? "Autenticación fallida o payload neutralizado. Los caracteres especiales fueron tratados como texto literal y no como código SQL."
                : "Usuario autenticado legítimamente. La consulta fue segura y validó exactamente los valores esperados.";

        return SqlResultResponse.builder()
                .vulnerable(false)
                .tipoEndpoint("MITIGADO (Consultas Parametrizadas / PreparedStatement)")
                .inputRecibido("username=" + username + ", password=" + password)
                .sqlEjecutado(sqlInterno)
                .explicacion(explicacion)
                .totalResultados(resultados.size())
                .datos(resultados)
                .build();
    }

    // =========================================================================
    // 2. ESCENARIO BÚSQUEDA / FILTRO
    // =========================================================================

    /**
     * [VULNERABLE] Búsqueda por término/rol concatenando la cláusula WHERE.
     * Permite ataques de tipo UNION SELECT o manipulación de filtros.
     */
    @SuppressWarnings("unchecked")
    public SqlResultResponse buscarVulnerable(String termino) {
        // CONSTRUCCIÓN INSEGURA: Se concatena el parámetro en un LIKE o WHERE
        String sql = "SELECT * FROM usuarios WHERE username LIKE '%" + termino + "%' OR rol = '" + termino + "'";

        List<Usuario> resultados;
        try {
            resultados = entityManager.createNativeQuery(sql, Usuario.class).getResultList();
        } catch (Exception e) {
            return SqlResultResponse.builder()
                    .vulnerable(true)
                    .tipoEndpoint("VULNERABLE (Búsqueda con SQL Dinámico Inseguro)")
                    .inputRecibido("termino=" + termino)
                    .sqlEjecutado(sql)
                    .explicacion("Error de sintaxis SQL inyectada: " + e.getMessage())
                    .totalResultados(0)
                    .datos(Collections.emptyList())
                    .build();
        }

        return SqlResultResponse.builder()
                .vulnerable(true)
                .tipoEndpoint("VULNERABLE (Búsqueda con SQL Dinámico Inseguro)")
                .inputRecibido("termino=" + termino)
                .sqlEjecutado(sql)
                .explicacion("Consulta ejecutada concatenando la entrada. Probar payloads como \"' OR '1'='1\" o \"' UNION SELECT 999,'hacker','pass','hacker@mail.com','ADMIN',99999.0 -- \".")
                .totalResultados(resultados.size())
                .datos(resultados)
                .build();
    }

    /**
     * [MITIGADO / SEGURO] Búsqueda utilizando consulta parametrizada con :termino.
     */
    public SqlResultResponse buscarMitigado(String termino) {
        List<Usuario> resultados = usuarioRepository.searchSecure(termino);
        String sqlInterno = "SELECT u FROM Usuario u WHERE u.username LIKE %:termino% OR u.email LIKE %:termino% (Safe Parameter Binding)";

        return SqlResultResponse.builder()
                .vulnerable(false)
                .tipoEndpoint("MITIGADO (Búsqueda Parametrizada Segura)")
                .inputRecibido("termino=" + termino)
                .sqlEjecutado(sqlInterno)
                .explicacion("Consulta segura ejecutada. Los operadores de comodín y caracteres maliciosos son escapados y enlazados como parámetros.")
                .totalResultados(resultados.size())
                .datos(resultados)
                .build();
    }

    // =========================================================================
    // 3. MÉTODOS AUXILIARES
    // =========================================================================

    /**
     * Obtener todos los usuarios registrados.
     */
    public List<Usuario> listarTodos() {
        return usuarioRepository.findAll();
    }

    /**
     * Crear o guardar un nuevo usuario.
     */
    public Usuario guardarUsuario(Usuario usuario) {
        return usuarioRepository.save(usuario);
    }

    /**
     * Restablecer los datos iniciales de la base de datos para pruebas.
     */
    public void reiniciarDatosPrueba() {
        usuarioRepository.deleteAll();
        usuarioRepository.save(new Usuario(null, "admin", "admin123", "administrador@empresa.com", "ADMIN", 5000.00));
        usuarioRepository.save(new Usuario(null, "juan_perez", "claveJuan2024", "juan.perez@empresa.com", "USER", 1800.50));
        usuarioRepository.save(new Usuario(null, "maria_gomez", "mariaSecret!", "maria.gomez@empresa.com", "USER", 2200.00));
        usuarioRepository.save(new Usuario(null, "carlos_ruiz", "carlosPass99", "carlos.ruiz@empresa.com", "MANAGER", 3500.75));
    }
}
