package com.ejemplo.sqlinjection.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * DTO para devolver una respuesta estructurada tanto a la API (Postman/Bruno)
 * como al frontend interactivo (index.html), detallando la consulta ejecutada,
 * el estado de vulnerabilidad y los registros devueltos.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SqlResultResponse {
    private boolean vulnerable;          // true si se ejecutó por el endpoint vulnerable, false si fue mitigado
    private String tipoEndpoint;         // "VULNERABLE (Concatenación directa)" o "MITIGADO (Consultas Parametrizadas)"
    private String inputRecibido;        // Parámetro de entrada recibido desde el cliente
    private String sqlEjecutado;         // Sentencia SQL final construida y enviada a la BD
    private String explicacion;          // Explicación técnica de lo ocurrido (riesgo o protección aplicada)
    private int totalResultados;         // Cantidad de registros encontrados
    private List<?> datos;               // Lista de usuarios o resultados obtenidos
}
