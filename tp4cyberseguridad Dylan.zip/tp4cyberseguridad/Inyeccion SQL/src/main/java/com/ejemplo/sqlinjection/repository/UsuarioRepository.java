package com.ejemplo.sqlinjection.repository;

import com.ejemplo.sqlinjection.model.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Capa de repositorio JPA para la entidad Usuario.
 * Los métodos aquí definidos utilizan consultas parametrizadas internamente (PreparedStatements),
 * lo que representa el enfoque SEGURO / MITIGADO contra Inyección SQL.
 */
@Repository
public interface UsuarioRepository extends JpaRepository<Usuario, Long> {

    /**
     * Enfoque Seguro 1: Consulta derivada de Spring Data JPA.
     * Spring Data genera internamente una consulta parametrizada con PreparedStatement.
     */
    Optional<Usuario> findByUsernameAndPassword(String username, String password);

    /**
     * Enfoque Seguro 2: Consulta JPQL con parámetros nombrados (:username, :password).
     * El motor de JPA trata los valores como datos literales y nunca como sentencias ejecutables.
     */
    @Query("SELECT u FROM Usuario u WHERE u.username = :username AND u.password = :password")
    Optional<Usuario> findByCredentialsSecure(@Param("username") String username, @Param("password") String password);

    /**
     * Enfoque Seguro 3: Búsqueda segura con coincidencia parcial de texto mediante parámetros.
     */
    @Query("SELECT u FROM Usuario u WHERE u.username LIKE %:termino% OR u.email LIKE %:termino%")
    List<Usuario> searchSecure(@Param("termino") String termino);
}
