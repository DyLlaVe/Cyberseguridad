package ar.edu.centro8.ps.jwt.security.config;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import ar.edu.centro8.ps.jwt.model.Permission;
import ar.edu.centro8.ps.jwt.model.Role;
import ar.edu.centro8.ps.jwt.model.UserSec;
import ar.edu.centro8.ps.jwt.repository.IPermissionRepository;
import ar.edu.centro8.ps.jwt.repository.IRoleRepository;
import ar.edu.centro8.ps.jwt.repository.IUserRepository;
import jakarta.transaction.Transactional;

@Component
public class DataLoader implements CommandLineRunner {
    @Autowired IUserRepository userRepo;
    @Autowired IRoleRepository roleRepo;
    @Autowired IPermissionRepository permRepo;
    @Autowired PasswordEncoder encoder;

    @Override
    @Transactional 
    public void run(String... args) {
        if (userRepo.count() > 0) return; // ya cargado

        Permission read = permRepo.save(new Permission(null, "READ"));
        Permission create = permRepo.save(new Permission(null, "CREATE"));

        Role admin = roleRepo.save(new Role(null, "ADMIN", new HashSet<>(Set.of(read, create))));
        Role user  = roleRepo.save(new Role(null, "USER",  new HashSet<>(Set.of(read))));

        userRepo.save(new UserSec(null, "admin", encoder.encode("1234"), true, true, true, true, new HashSet<>(Set.of(admin))));
        userRepo.save(new UserSec(null, "user",  encoder.encode("1234"), true, true, true, true, new HashSet<>(Set.of(user))));
    }
}