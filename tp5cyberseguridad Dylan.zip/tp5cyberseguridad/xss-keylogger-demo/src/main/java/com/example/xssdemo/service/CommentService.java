package com.example.xssdemo.service;

import com.example.xssdemo.model.Comment;
import com.example.xssdemo.repository.CommentRepository;
import org.springframework.stereotype.Service;
import org.springframework.web.util.HtmlUtils;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class CommentService {

    private final CommentRepository commentRepository;

    public CommentService(CommentRepository commentRepository) {
        this.commentRepository = commentRepository;
    }

    /**
     * VULNERABLE: Guarda el comentario exactamente como se recibe, permitiendo que
     * etiquetas HTML y scripts JavaScript (como Keyloggers) se almacenen crudos en
     * la BD.
     */
    public Comment saveVulnerable(Comment comment) {
        comment.setIsMitigated(false);
        return commentRepository.save(comment);
    }

    /**
     * MITIGADO: Aplica saneamiento (HTML Escaping) antes de almacenar en la base de
     * datos.
     * Convierte caracteres especiales como '<', '>', '"', '&' en sus entidades HTML
     * seguras
     * (&lt;, &gt;, &quot;, &amp;), evitando que el navegador ejecute cualquier
     * script inyectado.
     */

    public Comment saveMitigated(Comment comment) {
        comment.setIsMitigated(true);
        if (comment.getAuthor() != null) {
            comment.setAuthor(HtmlUtils.htmlEscape(comment.getAuthor()));
        }
        if (comment.getContent() != null) {
            comment.setContent(HtmlUtils.htmlEscape(comment.getContent()));
        }
        return commentRepository.save(comment);
    }

    /**
     * Devuelve todos los comentarios vulnerables guardados en crudo.
     */
    public List<Comment> getVulnerableComments() {
        return commentRepository.findByIsMitigatedOrderByIdDesc(false);
    }

    /**
     * Devuelve los comentarios mitigados. Si por alguna razón hubiera entradas
     * crudas(raw inputs),
     * se asegura de sanitizarlos en la salida (Defense-in-Depth).
     */
    public List<Comment> getMitigatedComments() {
        List<Comment> comments = commentRepository.findByIsMitigatedOrderByIdDesc(true);
        return comments.stream().map(c -> new Comment(
                c.getId(),
                HtmlUtils.htmlEscape(c.getAuthor() != null ? c.getAuthor() : ""),
                HtmlUtils.htmlEscape(c.getContent() != null ? c.getContent() : ""),
                true,
                c.getCreatedAt())).collect(Collectors.toList());
    }

    /**
     * Limpia la base de datos para reiniciar las pruebas del laboratorio XSS.
     */
    public void clearAll() {
        commentRepository.deleteAll();
    }
}
