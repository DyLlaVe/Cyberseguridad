package com.example.xssdemo.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;

import java.time.LocalDateTime;

@Entity
@Table(name = "comments")
public class Comment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String author;

    @Column(columnDefinition = "TEXT", nullable = false)
    private String content;

    @Column(name = "is_mitigated")
    private Boolean isMitigated;

    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    public Comment() {
    }

    public Comment(Long id, String author, String content, Boolean isMitigated, LocalDateTime createdAt) {
        this.id = id;
        this.author = author;
        this.content = content;
        this.isMitigated = isMitigated;
        this.createdAt = createdAt;
    }

    @PrePersist
    /*
     * @PrePersist
     * Se ejecuta automáticamente antes de que una entidad Comment sea insertada
     * (persistida)
     * en la base de datos.
     */
    protected void onCreate() {
        if (this.createdAt == null) {
            this.createdAt = LocalDateTime.now();
        }
        if (this.isMitigated == null) {
            this.isMitigated = false;
        }
    }

    // Getters y Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Boolean getIsMitigated() {
        return isMitigated;
    }

    public void setIsMitigated(Boolean mitigated) {
        isMitigated = mitigated;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }
}

/*
 * @Column(columnDefinition = "TEXT", nullable = false):
 *
 * 1. ¿Por qué columnDefinition = "TEXT"?
 * - Capacidad para Payloads Largos: En JPA/Hibernate con MySQL, un atributo de
 * tipo String
 * se mapea por defecto a VARCHAR(255).
 * - Los payloads de inyección XSS (como los scripts de Keylogger con listeners
 * keydown y llamadas fetch)
 * o los mensajes extensos superan fácilmente el límite de 255 caracteres.
 * - Usar columnDefinition = "TEXT" fuerza a MySQL a crear la columna con el
 * tipo TEXT
 * (capaz de almacenar hasta 64 KB / 65.535 caracteres), evitando excepciones de
 * base de datos
 * como "Data truncation: Data too long for column".
 *
 * 2. ¿Por qué nullable = false?
 * - Garantiza a nivel del esquema de la base de datos (restricción NOT NULL)
 * que ningún
 * comentario pueda guardarse con contenido nulo.
 *
 * 3. Contexto en el laboratorio XSS:
 * - En el Endpoint Vulnerable (/api/vulnerable/comments): Se almacena el script
 * JavaScript
 * completo en crudo dentro de esta columna TEXT de la base de datos MySQL.
 * - En el Endpoint Mitigado (/api/mitigated/comments): El método
 * HtmlUtils.htmlEscape() convierte
 * caracteres como '<' en '&lt;' y '>' en '&gt;'. Esto incrementa la longitud
 * del texto
 * almacenado, por lo que el tipo TEXT también resulta ideal para almacenar el
 * payload sanitizado de forma segura.
 */

/*
 * updatable = false
 * Le indica a JPA / Hibernate que el valor de este campo se incluirá en la
 * sentencia INSERT inicial,
 * pero se excluirá de cualquier sentencia UPDATE posterior.
 * Esto garantiza la inmutabilidad de la fecha de creación:
 * una vez insertado el comentario en la base de datos, la fecha/hora original
 * no podrá
 * ser modificada ni alterada por actualizaciones posteriores.
 */

// Cada vez que un usuario publica un comentario y la aplicación va a guardarlo
// en la base de datos, @PrePersist salta automáticamente justo antes de guardar
// y hace dos cosas por ti:

// 🕒 Le pone la fecha y hora actual (LocalDateTime.now()): Así el sistema
// registra exactamente cuándo se creó el comentario sin que tú tengas que
// escribir la hora a mano.
// 🏷️ Le pone una marca por defecto (isMitigated = false): Si el comentario no
// especifica si es seguro o no, lo marca como "no mitigado" (vulnerable) por
// defecto.