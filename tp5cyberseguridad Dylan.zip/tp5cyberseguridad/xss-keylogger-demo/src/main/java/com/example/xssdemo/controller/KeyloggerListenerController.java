package com.example.xssdemo.controller;

import com.example.xssdemo.service.CommentService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Controlador que simula el servidor receptor del atacante (Keylogger Listener
 * / C2 Server).
 * Cuando el payload XSS malicioso se ejecuta en el navegador de la víctima,
 * envía
 * cada tecla presionada a este endpoint.
 */
@RestController
@RequestMapping("/api/keylogger")
@CrossOrigin(origins = "*")
public class KeyloggerListenerController {

    private final CommentService commentService;

    // Almacén en memoria de las teclas capturadas por el keylogger
    private static final List<KeyLogEntry> capturedLogs = Collections.synchronizedList(new ArrayList<>());

    public KeyloggerListenerController(CommentService commentService) {
        this.commentService = commentService;
    }

    public static class KeyLogEntry {
        private String key;
        private String sourceIp;
        private LocalDateTime timestamp;

        public KeyLogEntry() {
        }

        public KeyLogEntry(String key, String sourceIp, LocalDateTime timestamp) {
            this.key = key;
            this.sourceIp = sourceIp;
            this.timestamp = timestamp;
        }

        public String getKey() {
            return key;
        }

        public void setKey(String key) {
            this.key = key;
        }

        public String getSourceIp() {
            return sourceIp;
        }

        public void setSourceIp(String sourceIp) {
            this.sourceIp = sourceIp;
        }

        public LocalDateTime getTimestamp() {
            return timestamp;
        }

        public void setTimestamp(LocalDateTime timestamp) {
            this.timestamp = timestamp;
        }
    }

    /**
     * Endpoint receptor del Keylogger.
     * Soporta tanto GET como POST para recibir las teclas capturadas por
     * fetch/Image beacon.
     */
    @RequestMapping(value = "/log", method = { RequestMethod.GET, RequestMethod.POST })
    public ResponseEntity<String> receiveKeyLog(@RequestParam(value = "key", required = false) String key,
            @RequestBody(required = false) String body) {
        String keyLogged = (key != null) ? key : body;
        if (keyLogged != null && !keyLogged.isEmpty()) {
            capturedLogs.add(new KeyLogEntry(keyLogged, "127.0.0.1", LocalDateTime.now()));
        }
        return ResponseEntity.ok("OK");
    }

    /**
     * Devuelve la lista de teclas exfiltradas para mostrar en la consola del
     * atacante en el frontend.
     */
    @GetMapping("/logs")
    public ResponseEntity<List<KeyLogEntry>> getCapturedLogs() {
        return ResponseEntity.ok(new ArrayList<>(capturedLogs));
    }

    /**
     * Limpia los logs de teclas capturadas y los comentarios en BD.
     */
    @DeleteMapping("/logs")
    public ResponseEntity<Void> clearLogs() {
        capturedLogs.clear();
        commentService.clearAll();
        return ResponseEntity.noContent().build();
    }
}

/*
 * EXPLICACIÓN DE: private static final List<KeyLogEntry> capturedLogs =
 * Collections.synchronizedList(new ArrayList<>());
 *
 * 1. static (Compartido en memoria):
 * - Hace que la lista pertenezca a la clase entera y no a una instancia
 * particular.
 * - Permite que todas las peticiones HTTP entrantes escriban y lean en el mismo
 * lugar de la RAM.
 *
 * 2. final (Referencia fija):
 * - Garantiza que la variable capturedLogs siempre apuntará a esta misma lista
 * en memoria
 * y no podrá ser reasignada accidentalmente.
 *
 * 3. Collections.synchronizedList(...) (Seguridad multihilo / Thread-Safety):
 * - Spring Boot procesa cada petición de usuario en hilos (threads) separados
 * de forma simultánea.
 * - Un ArrayList estándar no es seguro cuando varios hilos intentan escribir al
 * mismo tiempo.
 * - Collections.synchronizedList() le coloca un candado automático (mutex) a la
 * lista:
 * si llegan múltiples pulsaciones de teclado simultáneas, las encola una a una
 * en orden
 * para guardarlas de forma segura sin corromper la aplicación.
 */

/*
 * EXPLICACIÓN DE LA CLASE ANIDADA ESTÁTICA (public static class KeyLogEntry):
 *
 * 1. ¿Puede ubicarse adentro de otra clase tal como acá?
 * - Sí, es una práctica estándar en Java conocida como Static Nested Class.
 * - Se usa cuando una clase secundaria solo tiene sentido dentro del contexto
 * de la clase principal,
 * manteniendo el código agrupado y organizado en un solo archivo sin crear
 * archivos .java adicionales.
 *
 * 2. ¿Qué es una clase estática en este contexto?
 * - Indica que no depende de una instancia de la clase contenedora
 * (KeyloggerListenerController) para existir.
 * - Se pueden instanciar objetos new KeyLogEntry(...) directamente sin
 * instanciar el controlador.
 *
 * 3. ¿Qué hace en esta aplicación?
 * - Funciona como un DTO (Data Transfer Object) para estructurar cada evento de
 * tecla capturada.
 * - Almacena 3 atributos clave:
 * * key: La tecla presionada ('a', 'Enter', etc.).
 * * sourceIp: La dirección IP de origen ('127.0.0.1').
 * * timestamp: La fecha y hora exacta del registro.
 */

/*
 * EXPLICACIÓN DEL ENDPOINT RECEPTOR /log (receiveKeyLog):
 *
 * Este endpoint es el "buzón receptor del atacante".
 * Cada vez que la víctima presiona una tecla en la pantalla vulnerable,
 * el script malicioso (Keylogger) envía silenciosamente una petición a este
 * buzón.
 *
 * Flujo de ejecución:
 * 1. Acepta métodos GET y POST (@RequestMapping(value = "/log", method = { GET,
 * POST })).
 * Permite recibir la tecla si viene en la URL (?key=a) o en el cuerpo de la
 * petición.
 * 2. Extrae la tecla recibida (keyLogged = (key != null) ? key : body).
 * 3. Si la tecla no está vacía, guarda un registro KeyLogEntry en la lista
 * compartida en memoria (capturedLogs).
 * 4. Responde con un estado HTTP 200 OK (ResponseEntity.ok("OK")) para que la
 * petición finalice
 * de forma limpia y desapercibida en el cliente.
 */
