package com.example.xssdemo.controller;

import com.example.xssdemo.model.Comment;
import com.example.xssdemo.service.CommentService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Controlador Mitigado contra XSS (Cross-Site Scripting).
 * Aplica HTML Escaping mediante Spring HtmlUtils.
 * Convierte etiquetas como <script> en entidades &lt;script&gt;, impidiendo
 * la ejecución del código JavaScript malicioso en el navegador del usuario.
 */
@RestController
@RequestMapping("/api/mitigated/comments")
@CrossOrigin(origins = "*")
public class MitigatedCommentController {

    private final CommentService commentService;

    public MitigatedCommentController(CommentService commentService) {
        this.commentService = commentService;
    }

    @GetMapping
    public ResponseEntity<List<Comment>> getComments() {
        return ResponseEntity.ok(commentService.getMitigatedComments());
    }

    @PostMapping
    public ResponseEntity<Comment> createComment(@RequestBody Comment comment) {
        Comment savedComment = commentService.saveMitigated(comment);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedComment);
    }
}
