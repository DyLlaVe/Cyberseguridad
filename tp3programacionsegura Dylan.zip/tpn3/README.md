# Trabajo Práctico N° 3 - Sistema Bancario REST con Spring Security

Este proyecto es una API REST desarrollada con **Spring Boot** y **Spring Security** que simula las operaciones básicas de un sistema bancario. Su propósito principal es demostrar la implementación de **autenticación HTTP Basic**, **gestión de sesiones sin estado (Stateless)** y **autorización basada en permisos (Authorities)**.

---

## 🚀 Tecnologías Utilizadas

- **Java**: 21
- **Spring Boot**: 3.4.4
  - `spring-boot-starter-web` (API REST)
  - `spring-boot-starter-security` (Autenticación y Autorización)
  - `spring-boot-devtools` (Herramientas de desarrollo)
- **Lombok**: Simplificación de código Java
- **Maven**: Gestor de dependencias y construcción

---

## 📁 Estructura del Proyecto

```text
src/main/java/ar/edu/centro8/ps/tpn3/
├── Tpn3Application.java           # Punto de entrada principal de Spring Boot
├── controller/
│   └── BankController.java        # Controlador REST con endpoints públicos y protegidos
└── security/config/
    └── SecurityConfig.java        # Configuración de seguridad, reglas de acceso y usuarios
```

---

## 🔐 Configuración de Seguridad y Funcionamiento

La seguridad se configura centralizadamente en la clase `SecurityConfig`.

### Características Clave:
1. **Autenticación HTTP Basic**: Las peticiones protegidas requieren enviar credenciales codificadas en el encabezado `Authorization` (ej. `Basic <credentials>`).
2. **Sesiones Stateless**: No se mantienen sesiones HTTP en el servidor (`SessionCreationPolicy.STATELESS`), lo que garantiza un diseño adecuado para APIs RESTful.
3. **Desactivación de CSRF**: Deshabilitado por ser una API REST sin estado.
4. **Codificación de Contraseñas**: Utiliza `NoOpPasswordEncoder` (contraseñas en texto plano) exclusivamente con fines educativos y de prueba.

---

### 🧠 Concepto: ¿Por qué esta app es Stateless vs cómo sería Stateful?

#### ⚡ 1. ¿Por qué es Stateless (Sin Estado)?
- **Sin `HttpSession`**: Spring Security tiene prohibido crear o buscar sesiones HTTP.
- **Autónoma por petición**: Cada request exige enviar las credenciales HTTP Basic. El servidor no "recuerda" al usuario entre peticiones.
- **Sin Cookies de Sesión**: No se genera `JSESSIONID`.
- **Desactivación de CSRF**: Al no haber cookies de sesión expuestas a navegadores, no existe riesgo de ataques CSRF basados en cookies.

#### 🔄 2. ¿Cómo sería al revés (Stateful / Con Estado)?
En una arquitectura **Stateful**:
1. El usuario hace login **una sola vez** (vía formulario o `/login`).
2. El servidor valida las credenciales y crea una sesión en memoria RAM (`HttpSession`), devolviendo una cookie `JSESSIONID`.
3. En las siguientes peticiones, el navegador adjunta automáticamente la cookie `JSESSIONID`. El usuario **ya no envía usuario/contraseña**.
4. Al hacer logout, la sesión en el servidor se destruye.

**Ejemplo de cómo cambiaría la configuración en Spring Security para ser Stateful:**
```java
@Bean
public SecurityFilterChain securityFilterChain(HttpSecurity httpSecurity) throws Exception {
    return httpSecurity
            .csrf(Customizer.withDefaults())
            .sessionManagement(session -> 
                session.sessionCreationPolicy(SessionCreationPolicy.IF_REQUIRED)
            )
            .formLogin(Customizer.withDefaults())
            .logout(Customizer.withDefaults())
            .authorizeHttpRequests(http -> {
                http.requestMatchers("/api/public/info").permitAll();
                http.requestMatchers("/api/secure/saldo").hasAuthority("READ");
                http.requestMatchers("/api/secure/transferencia").hasAuthority("WRITE");
                http.anyRequest().denyAll();
            })
            .build();
}
```

#### ⚖️ Cuadro Comparativo:

| Característica | Stateless (Sin Estado - Esta App) | Stateful (Con Estado) |
| :--- | :--- | :--- |
| **Envío de credenciales** | En **todas** las peticiones (`Authorization` header) | **Solo una vez** al iniciar sesión |
| **Identificador de usuario** | No se guarda nada en el servidor | Cookie de sesión (`JSESSIONID`) |
| **Memoria del Servidor** | Limpia (0 uso de memoria por sesión) | Almacena 1 sesión por cada usuario activo |
| **Protección CSRF** | No requerida (Desactivada) | **Muy requerida** (Activada) |
| **Casos de Uso** | APIs REST, Mobile Apps, Microservicios | Aplicaciones web tradicionales (HTML, Thymeleaf, JSP) |

---

## 👥 Usuarios y Permisos

La aplicación define los siguientes usuarios guardados en memoria (`InMemoryUserDetailsManager`). El rol y los permisos se cargan juntos con `authorities(...)`, porque si se usa `roles(...)` y después `authorities(...)`, el segundo reemplaza al primero y el rol se pierde:

| Usuario | Contraseña | Rol | Autoridades (Permisos) | Descripción |
| :--- | :--- | :--- | :--- | :--- |
| `admin` | `admin123` | `ROLE_ADMIN` | `READ`, `WRITE` | Acceso total al sistema |
| `cajero` | `cajero123` | `ROLE_CAJERO` | `READ`, `WRITE` | Puede consultar saldo y realizar transferencias |
| `cliente` | `cliente123` | `ROLE_CLIENTE` | `READ` | Solo puede consultar saldo |

---

## 🛠️ Endpoints de la API

Los endpoints están expuestos en el controlador `BankController`:

| Método | Endpoint | Nivel de Acceso / Permiso | Usuarios Permitidos | Respuesta Esperada |
| :---: | :--- | :--- | :--- | :--- |
| `GET` | `/api/public/info` | **Público** (`permitAll`) | Todos (Sin autenticación) | `"Bienvenido al sistema bancario - Acceso público"` |
| `GET` | `/api/secure/saldo` | Requiere permiso `READ` | `admin`, `cajero`, `cliente` | `"Consulta de saldo realizada con éxito"` |
| `GET` | `/api/secure/transferencia` | Requiere permiso `WRITE` | `admin`, `cajero` | `"Transferencia realizada con éxito"` |
| `*` | *Cualquier otro endpoint* | **Denegado** (`denyAll`) | Ninguno | `403 Forbidden` / `401 Unauthorized` |

---

## ⚙️ Cómo Ejecutar la Aplicación

### Requisitos Previos
- Tener instalado **Java JDK 21** o superior.
- Maven (opcional, ya que se incluye el wrapper `./mvnw`).

### Pasos para iniciar:
1. Clonar o abrir el proyecto en la terminal dentro de la carpeta raíz (`tpn3`).
2. Ejecutar la aplicación mediante Maven Wrapper:

#### En Linux / macOS:
```bash
./mvnw spring-boot:run
```

#### En Windows (CMD / PowerShell):
```powershell
.\mvnw.cmd spring-boot:run
```

La aplicación se iniciará en `http://localhost:8080`.

---

## 🧪 Pruebas con cURL

Puedes probar los diferentes niveles de acceso utilizando `curl` desde tu terminal:

### 1. Endpoint Público (Sin autenticación)
```bash
curl -i http://localhost:8080/api/public/info
```
*Resultado esperado:* `200 OK`

### 2. Consulta de Saldo (`READ`)
- **Como `cliente` (Permitido):**
  ```bash
  curl -i -u cliente:cliente123 http://localhost:8080/api/secure/saldo
  ```
  *Resultado esperado:* `200 OK`

- **Sin credenciales (Denegado):**
  ```bash
  curl -i http://localhost:8080/api/secure/saldo
  ```
  *Resultado esperado:* `401 Unauthorized`

### 3. Realizar Transferencia (`WRITE`)
- **Como `cajero` (Permitido):**
  ```bash
  curl -i -u cajero:cajero123 http://localhost:8080/api/secure/transferencia
  ```
  *Resultado esperado:* `200 OK`

- **Como `cliente` (Denegado - Falta permiso `WRITE`):**
  ```bash
  curl -i -u cliente:cliente123 http://localhost:8080/api/secure/transferencia
  ```
  *Resultado esperado:* `403 Forbidden`

---

## 🐶 Pruebas con Bruno API Client

Se incluye la carpeta `bruno/` en la raíz del proyecto para importar y ejecutar fácilmente las peticiones en Bruno.

### Peticiones Incluidas:
1. `01 - Info Publica`: `GET /api/public/info` (Público, respuesta `200 OK`)
2. `02 - Consultar Saldo (Cliente)`: `GET /api/secure/saldo` (Auth `cliente:cliente123`, respuesta `200 OK`)
3. `03 - Consultar Saldo (Sin Auth - 401)`: `GET /api/secure/saldo` (Sin credenciales, respuesta `401 Unauthorized`)
4. `04 - Transferencia (Cajero)`: `GET /api/secure/transferencia` (Auth `cajero:cajero123`, respuesta `200 OK`)
5. `05 - Transferencia (Admin)`: `GET /api/secure/transferencia` (Auth `admin:admin123`, respuesta `200 OK`)
6. `06 - Transferencia (Cliente - 403 Forbidden)`: `GET /api/secure/transferencia` (Auth `cliente:cliente123`, respuesta `403 Forbidden`)

