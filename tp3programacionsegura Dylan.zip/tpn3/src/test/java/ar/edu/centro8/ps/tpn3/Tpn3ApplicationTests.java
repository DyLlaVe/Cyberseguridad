package ar.edu.centro8.ps.tpn3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Tpn3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
