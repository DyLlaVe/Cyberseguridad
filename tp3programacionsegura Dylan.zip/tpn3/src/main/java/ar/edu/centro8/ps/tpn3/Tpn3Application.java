package ar.edu.centro8.ps.tpn3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Tpn3Application {

	public static void main(String[] args) {
		SpringApplication.run(Tpn3Application.class, args);
	}

}
