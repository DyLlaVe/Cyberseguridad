package ar.edu.centro8.ps.tpn3.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class BankController {

    @GetMapping("/api/public/info")
    public String getPublicInfo() {
        return "Bienvenido al sistema bancario - Acceso público";
    }

    @GetMapping("/api/secure/saldo")
    public String getSaldo() {
        return "Consulta de saldo realizada con éxito";
    }

    @GetMapping("/api/secure/transferencia")
    public String doTransferencia() {
        return "Transferencia realizada con éxito";
    }
}
