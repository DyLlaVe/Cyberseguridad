package com.example.tp.dylan.tp1cyberseguridad;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Tp1cyberseguridadApplicationTests {

	@Test
	void contextLoads() {
	}

}
