package com.example.tp.dylan.tp1cyberseguridad;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Tp1cyberseguridadApplication {

	public static void main(String[] args) {
		SpringApplication.run(Tp1cyberseguridadApplication.class, args);
	}

}
