package com.example.tp.dylan.tp1cyberseguridad.controller;

import org.springframework.web.bind.annotation.*;

import com.example.tp.dylan.tp1cyberseguridad.models.Invoice;
import com.example.tp.dylan.tp1cyberseguridad.service.InvoiceService;

@RestController
@RequestMapping("/api/invoices")
public class InvoiceController {

    private final InvoiceService invoiceService;

    public InvoiceController(InvoiceService invoiceService) {
        this.invoiceService = invoiceService;
    }

    @GetMapping("/vulnerable/{id}")
    public Invoice getInvoiceVulnerable(
            @PathVariable Long id,
            @RequestHeader("X-User-Name") String requestingUser) {
        return invoiceService.getInvoiceVulnerable(id);
    }

    @GetMapping("/secure/{id}")
    public Invoice getInvoiceSecure(
            @PathVariable Long id,
            @RequestHeader("X-User-Name") String requestingUser) {
        return invoiceService.getInvoiceSecure(id, requestingUser);
    }

    
}