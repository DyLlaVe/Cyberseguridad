package com.example.tp.dylan.tp1cyberseguridad.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.tp.dylan.tp1cyberseguridad.models.Invoice;

public interface InvoiceRepository extends JpaRepository<Invoice, Long> {
}