package com.example.tp.dylan.tp1cyberseguridad.service;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import com.example.tp.dylan.tp1cyberseguridad.models.Invoice;
import com.example.tp.dylan.tp1cyberseguridad.repository.InvoiceRepository;

@Service
public class InvoiceService {

    private final InvoiceRepository invoiceRepository;

    public InvoiceService(InvoiceRepository invoiceRepository) {
        this.invoiceRepository = invoiceRepository;
    }

    public Invoice getInvoiceVulnerable(Long id) {
        return invoiceRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Factura no encontrada"));
    }

    public Invoice getInvoiceSecure(Long id, String requestingUser) {
        Invoice invoice = invoiceRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Factura no encontrada"));

        if (!invoice.getOwnerUsername().equals(requestingUser)) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN,
                    "Acceso denegado: la factura #" + id + " no pertenece a " + requestingUser);
        }

        return invoice;
    }
    
}